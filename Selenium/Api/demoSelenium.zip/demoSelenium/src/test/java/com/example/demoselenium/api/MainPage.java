package com.example.demoselenium.api;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class MainPage {
    public static void main(String[] args){
        double difference = execute();
        System.out.println(""+difference);
    }

    public static double execute() {
        System.setProperty("webdriver.chrome.driver","src/test/driver/chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://it.calcuworld.com/convertitori/convertitore-miglia-km/");
        driver.manage().window().setSize(new Dimension(1290, 700));
        try{
            Thread.sleep(2000);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }

        driver.findElement(By.cssSelector(".css-47sehv > span")).click();
        //alternativamente andava bene anche driver.findElement(By.xpath("//*[@id=\"qc-cmp2-ui\"]/div[2]/div/button[2]")).click();
        try{
            Thread.sleep(1000);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"post-611\"]/div/div[4]/table/tbody/tr[1]/td/form/input")).sendKeys("20");
        driver.findElement(By.xpath("//*[@id=\"post-611\"]/div/div[4]/table/tbody/tr[1]/td/form/a")).click();
        try{
            Thread.sleep(1000);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
        String miglia = driver.findElement(By.xpath("//*[@id=\"post-611\"]/div/div[4]/table/tbody/tr[2]/td/input")).getAttribute("value");
        System.out.println("Stringa: "+miglia);

        double migliaDouble = Double.parseDouble(miglia);
        double time75 = migliaDouble/75;
        double time55 = migliaDouble/55;

        double difference = (time55-time75)*60;

        System.out.println(difference);

        try{
            Thread.sleep(1000);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
        driver.close();
        return difference;
    }

}
