package com.example.demoselenium.api;


import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertTrue;


public class MainPageTest {

    @Test
    void testExecute() {
        double actual = MainPage.execute();
        assertTrue(actual>1/6 && actual<10);
    }
}
